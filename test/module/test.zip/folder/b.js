module.exports = {
	b: 200,
	a: require("../a.js"),
	mod3: require("mod3"),
	mod4: require("mod4"),
	p1: require("./p1")
};