module.exports = {
	b: 200,
	a: require("../a.js"),
	p1: require("./p1")
};